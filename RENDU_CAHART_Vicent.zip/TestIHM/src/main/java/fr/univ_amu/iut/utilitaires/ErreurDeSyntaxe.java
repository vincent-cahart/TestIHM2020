package fr.univ_amu.iut.utilitaires;

public class ErreurDeSyntaxe extends Exception {
    ErreurDeSyntaxe(String message) {
        super(message);
    }
}
