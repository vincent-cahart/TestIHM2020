open module examenIHM {
    requires javafx.base;
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;

    exports fr.univ_amu.iut.utilitaires;
    exports fr.univ_amu.iut.ihm;
}
